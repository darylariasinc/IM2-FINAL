<?php


define('DB_HOST', 'localhost');
define('DB_NAME', 'im2-final');
define('DB_USER', 'root');
define('DB_PASS', '');
