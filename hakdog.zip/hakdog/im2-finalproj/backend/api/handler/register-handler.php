<?php

include 'object.php';

header('Content-Type: application/json');

// Handle CORS headers for all requests
header('Access-Control-Allow-Origin: http://localhost:5173'); // Replace with the actual URL of your Vue.js frontend
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit();
}

$database = new Database();
$conn = $database->getDb();

if (!$database->getState()) {
    die(json_encode(['success' => false, 'message' => $database->getErrMsg()]));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    // Check if the required fields are set
    if (
        isset($data['fname']) &&
        isset($data['lname']) &&
        isset($data['email']) &&
        isset($data['address']) &&
        isset($data['gender']) &&
        isset($data['birthdate']) &&
        isset($data['password'])
    ) {
        // Extract data from the request
        $fname = $data['fname'];
        $lname = $data['lname'];
        $email = $data['email'];
        $address = $data['address'];
        $gender = $data['gender'];
        $birthdate = $data['birthdate'];
        $password = password_hash($data['password'], PASSWORD_DEFAULT);

        // Perform your registration logic with PDO
        $stmt = $conn->prepare("INSERT INTO userinfo (fname, lname, email, address, gender, birthdate, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$fname, $lname, $email, $address, $gender, $birthdate, $password]);

        // Check if registration was successful
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Registration failed']);
        }
    } else {
        // Invalid request, missing parameters
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
    }
} else {
    // Invalid request method
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
