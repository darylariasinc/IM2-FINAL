<template>
  <div class="register-container">
    <h1>Register</h1>
    <form>
      <div class="form-group">
        <label for="fname">First Name:</label>
        <input type="text" v-model="fname" placeholder="Enter your first name" id="fname" required>
      </div>
      <div class="form-group">
        <label for="lname">Last Name:</label>
        <input type="text" v-model="lname" placeholder="Enter your last name" id="lname" required>
      </div>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" v-model="email" placeholder="Enter your email" id="email" required>
      </div>
      <div class="form-group">
        <label for="address">Address:</label>
        <input type="text" v-model="address" placeholder="Enter your address" id="address" required>
      </div>
      <div class="form-group">
        <label for="gender">Gender:</label>
        <select v-model="gender" id="gender" required>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </div>
      <div class="form-group">
        <label for="birthdate">Birthdate:</label>
        <input type="date" v-model="birthdate" id="birthdate" required>
      </div>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" v-model="password" placeholder="Enter your password" id="password" required>
      </div>
      <button type="button" @click="register">Register</button>
    </form>
    <p class="login-link">Already have an account? <router-link to="/">Login</router-link></p>
  </div>
</template>

<script>
import Swal from 'sweetalert2';

export default {
  data() {
    return {
      fname: '',
      lname: '',
      email: '',
      address: '',
      gender: 'male',
      birthdate: '',
      password: '',
    };
  },
  methods: {
    register() {
      if (!this.validateForm()) {
        return;
      }

      fetch('http://localhost/im3d/api/register-handler.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        mode: 'cors',
        body: JSON.stringify({
          fname: this.fname,
          lname: this.lname,
          email: this.email,
          address: this.address,
          gender: this.gender,
          birthdate: this.birthdate,
          password: this.password,
        }),
      })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            this.showSuccessMessage('Registration Successful!');
            this.$router.push('/'); // Redirect to login page after successful registration
          } else {
            this.showErrorMessage(data.message || 'An error occurred during registration');
          }
        })
        .catch(error => {
          console.error('Error during registration:', error);
          this.showErrorMessage('An error occurred during registration');
        });
    },
    validateForm() {
      if (
        !this.fname ||
        !this.lname ||
        !this.email ||
        !this.address ||
        !this.birthdate ||
        !this.password
      ) {
        this.showErrorMessage('Please fill in all required fields');
        return false;
      }
      return true;
    },
    showSuccessMessage(message) {
      Swal.fire({
        icon: 'success',
        title: message,
        showConfirmButton: false,
        timer: 1500,
        timerProgressBar: true,
        toast: true,
        position: 'top-end',
        showCloseButton: true,
      });
    },
    showErrorMessage(message) {
      Swal.fire({
        icon: 'error',
        title: 'Registration Failed',
        text: message,
      });
    },
  },
};
</script>

<style scoped>
.register-container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #3498db;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  text-align: center;
  background-color: #fff;
}

form {
  display: flex;
  flex-direction: column;
}

.form-group {
  margin-bottom: 15px;
}

label {
  font-size: 14px;
  margin-bottom: 5px;
  color: #3498db;
}

input,
select,
button {
  padding: 10px;
  width: 100%;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 3px;
  font-size: 16px;
  margin-bottom: 10px;
}

button {
  background-color: #2ecc71;
  color: #fff;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #27ae60;
}

.login-link {
  margin-top: 10px;
  font-size: 14px;
}

.login-link a {
  color: #3498db;
  text-decoration: none;
  font-weight: bold;
}

.login-link a:hover {
  text-decoration: underline;
}
</style>
