<template>
  <div class="login-container">
    <h1>Login</h1>
    <form>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" v-model="email" placeholder="Enter your email" id="email" required>
      </div>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" v-model="password" placeholder="Enter your password" id="password" required>
      </div>
      <button type="button" @click="login">Login</button>
      <p class="register-link">Don't have an account? <router-link to="/register">Register</router-link></p>
    </form>
  </div>
</template>

<script>
import Swal from 'sweetalert2';

export default {
  data() {
    return {
      email: '',
      password: '',
    };
  },
  methods: {
    login() {
      // Check if email or password is empty
      if (!this.email || !this.password) {
        // Display an error notification for empty fields
        Swal.fire({
          icon: 'error',
          title: 'Login Failed',
          text: 'Please enter both email and password',
        });
        return;
      }

      // Handle preflight OPTIONS request
      fetch('http://localhost/im2-finalproj/api/handler.php', {
        method: 'OPTIONS',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      // Send a POST request to your PHP backend with the correct URL
      fetch('http://localhost/im2-finalproj/api/handler.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        mode: 'cors', // Ensure this line is present
        body: JSON.stringify({
          email: this.email,
          password: this.password,
        }),
      })
      .then(response => {
        // Check if the response status is 204 (No Content)
        if (response.status === 204) {
          return Promise.resolve(response);
        } else {
          return response.json();
        }
      })
      .then(data => {
        if (data && data.success) {
          // Login successful
          Swal.fire({
            icon: 'success',
            title: 'Login Successful!',
            showConfirmButton: false,
            timer: 1500,
            timerProgressBar: true,
            toast: true,
            position: 'top-end',
            showCloseButton: true,
          });
        } else {
          // Login failed, display an error message
          Swal.fire({
            icon: 'error',
            title: 'Login Failed',
            text: data.message || 'An error occurred',
          });
        }
      })
      .catch(error => {
        // Log the error for debugging
        console.error('Error during login:', error);

        // Display a generic error message to the user
        Swal.fire({
          icon: 'error',
          title: 'Login Failed',
          text: 'An error occurred during login',
        });
      });
    },
  },
};
</script>

<style scoped>
.login-container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  text-align: center;
}

form {
  display: flex;
  flex-direction: column;
}

.form-group {
  margin-bottom: 15px;
}

label {
  font-size: 14px;
  margin-bottom: 5px;
}

input {
  padding: 10px;
  width: 100%;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 3px;
  font-size: 16px;
  margin-bottom: 10px;
}

button {
  padding: 10px;
  background-color: #3498db;
  color: #fff;
  border: none;
  border-radius: 3px;
  font-size: 16px;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #2980b9;
}

.register-link {
  margin-top: 10px;
  font-size: 14px;
}

.register-link a {
  color: #3498db;
  text-decoration: none;
  font-weight: bold;
}

.register-link a:hover {
  text-decoration: underline;
}
</style>
