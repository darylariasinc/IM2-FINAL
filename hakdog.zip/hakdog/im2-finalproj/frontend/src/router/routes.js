// router/routes.js
import { createRouter, createWebHistory } from 'vue-router';
import Register from '../components/register.vue';
import Login from '../components/login.vue';
import Dashboard from '../components/dashboard.vue';

const routes = [
  { path: '/register', component: Register },
  { path: '/login', component: Login },
  { path: '/dashboard', component: Dashboard, meta: { requiresAuth: true } },
  { path: '/', redirect: '/login' }, // Redirect to /login for the root path
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
