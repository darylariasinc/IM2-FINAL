<template>
    <div>
      <h2>User Account Management</h2>
      
      <!-- Add New User Form -->
      <form @submit.prevent="addUser">
        <label>Email:</label>
        <input type="email" v-model="newUser.email" required>
        <label>Name:</label>
        <input type="text" v-model="newUser.name" required>
        <button type="submit">Add User</button>
      </form>
  
      <table>
        <thead>
          <tr>
            <th>Email</th>
            <th>Name</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in users" :key="user.id">
            <td>{{ user.email }}</td>
            <td>{{ user.name }}</td>
            <td>
              <button @click="editUser(user.id)">Edit</button>
              <button @click="deleteUser(user.id)">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <script>
  import Swal from 'sweetalert2';
  
  export default {
    data() {
      return {
        users: [],
        newUser: {
          email: '',
          name: '',
        },
      };
    },
    mounted() {
      this.fetchUsers();
    },
    methods: {
      fetchUsers() {
        // Simulate fetching users for demonstration purposes
        this.users = [
          { id: 1, email: 'user1@example.com', name: 'User 1' },
          { id: 2, email: 'user2@example.com', name: 'User 2' },
          // Add more users as needed
        ];
      },
      addUser() {
        // Simulate adding a new user for demonstration purposes
        const newUser = {
          id: this.users.length + 1,
          email: this.newUser.email,
          name: this.newUser.name,
        };
  
        this.users.push(newUser);
  
        // Clear the form
        this.newUser.email = '';
        this.newUser.name = '';
  
        // Display a success notification using SweetAlert2
        Swal.fire({
          icon: 'success',
          title: 'User Added Successfully!',
          showConfirmButton: false,
          timer: 1500,
        });
      },
      editUser(userId) {
        // Implement edit user logic using Vue.js methods
        console.log('Editing user with ID:', userId);
  
        // Display an edit success notification using SweetAlert2
        Swal.fire({
          icon: 'success',
          title: 'User Edited Successfully!',
          showConfirmButton: false,
          timer: 1500,
        });
      },
      deleteUser(userId) {
        // Implement delete user logic using Vue.js methods
        console.log('Deleting user with ID:', userId);
  
        // Display a delete success notification using SweetAlert2
        Swal.fire({
          icon: 'success',
          title: 'User Deleted Successfully!',
          showConfirmButton: false,
          timer: 1500,
        });
      }
    }
  }
  </script>
  