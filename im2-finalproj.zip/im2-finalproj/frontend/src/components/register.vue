<template>
  <div class="register-container">
    <h1>Register</h1>
    <form>
      <div class="form-group">
        <label for="fname">First Name:</label>
        <input type="text" v-model="fname" placeholder="Enter your first name" id="fname" required>
      </div>
      <div class="form-group">
        <label for="lname">Last Name:</label>
        <input type="text" v-model="lname" placeholder="Enter your last name" id="lname" required>
      </div>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" v-model="email" placeholder="Enter your email" id="email" required>
      </div>
      <div class="form-group">
        <label for="address">Address:</label>
        <input type="text" v-model="address" placeholder="Enter your address" id="address" required>
      </div>
      <div class="form-group">
        <label for="gender">Gender:</label>
        <select v-model="gender" id="gender" required>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </div>
      <div class="form-group">
        <label for="birthdate">Birthdate:</label>
        <input type="date" v-model="birthdate" id="birthdate" required>
      </div>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" v-model="password" placeholder="Enter your password" id="password" required>
      </div>
      <button type="button" @click="register">Register</button>
    </form>
    <p class="login-link">Already have an account? <router-link to="/">Login</router-link></p>
    <div v-if="showSuccessNotification" class="success-notification">
      Registration Successful! You can now log in.
    </div>
  </div>

</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import Swal from 'sweetalert2';

const router = useRouter(); // Use useRouter and assign it to the router variable

const fname = ref('');
const lname = ref('');
const email = ref('');
const address = ref('');
const gender = ref('male');
const birthdate = ref('');
const password = ref('');
const showSuccessNotification = ref(false); // Define and initialize showSuccessNotification

const register = async () => {
  if (!validateForm()) {
    return;
  }

  const backendUrl = 'http://localhost/im2-finalproj/backend/api/handler/register-handler.php';

  try {
    const response = await fetch(backendUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      mode: 'no-cors',  // Use 'no-cors' to disable CORS policy check temporarily
      body: JSON.stringify({
        fname: fname.value,
        lname: lname.value,
        email: email.value,
        address: address.value,
        gender: gender.value,
        birthdate: birthdate.value,
        password: password.value,
      }),
    });

    // Handle response as needed
    console.log('Response:', response);

    if (response.ok) {
      showSuccessNotification.value = true; // Set showSuccessNotification to true
      showSuccessMessage('Registration Successful! You can now log in.');
      // Redirect to the login page after successful registration
      router.push('/');
    } else {
      showErrorMessage('An error occurred during registration');
    }
  } catch (error) {
    console.error('Error during registration:', error);
    showErrorMessage('An error occurred during registration');
  }
};

const validateForm = () => {
  if (
    !fname.value ||
    !lname.value ||
    !email.value ||
    !address.value ||
    !birthdate.value ||
    !password.value
  ) {
    showErrorMessage('Please fill in all required fields');
    return false;
  }
  return true;
};

const showSuccessMessage = (message) => {
  Swal.fire({
    icon: 'success',
    title: message,
    showConfirmButton: false,
    timer: 1500,
    timerProgressBar: true,
    toast: true,
    position: 'top-end',
    showCloseButton: true,
  });
};

const showErrorMessage = (message) => {
  Swal.fire({
    icon: 'error',
    title: 'Registration Failed',
    text: message,
  });
};
</script>

<style scoped>
.register-container {
  max-width: 400px;
  margin: 0 auto;
  padding: 20px;
  border: 1px solid #3498db;
  border-radius: 5px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  text-align: center;
  background-color: #fff;
}

form {
  display: flex;
  flex-direction: column;
}

.form-group {
  margin-bottom: 15px;
}

label {
  font-size: 14px;
  margin-bottom: 5px;
  color: #3498db;
}

input,
select,
button {
  padding: 10px;
  width: 100%;
  box-sizing: border-box;
  border: 1px solid #ccc;
  border-radius: 3px;
  font-size: 16px;
  margin-bottom: 10px;
}

button {
  background-color: #2ecc71;
  color: #fff;
  cursor: pointer;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #27ae60;
}

.login-link {
  margin-top: 10px;
  font-size: 14px;
}

.login-link a {
  color: #3498db;
  text-decoration: none;
  font-weight: bold;
}

.login-link a:hover {
  text-decoration: underline;
}
</style>
