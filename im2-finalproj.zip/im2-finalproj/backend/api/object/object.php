<?php

class Database {
    private $conn;
    private $error;

    public function __construct() {
        require_once 'config.php';

        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME;
            $this->conn = new PDO($dsn, DB_USER, DB_PASSWORD);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            $this->error = $e->getMessage();
        }
    }

    public function getDb() {
        return $this->conn;
    }

    public function getState() {
        return $this->error === null;
    }

    public function getErrMsg() {
        return $this->error;
    }

    // Example: Login user
    public function loginUser($email, $password) {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = :email AND password = :password");
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $password);
            $stmt->execute();

            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            return $user ? $user : false;
        } catch (PDOException $e) {
            return false;
        }
    }
}

?>
