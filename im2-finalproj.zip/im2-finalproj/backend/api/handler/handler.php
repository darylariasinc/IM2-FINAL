<?php
include 'object.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Allow requests from any origin for development purposes
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    // Respond to preflight request
    http_response_code(200);
    exit();
}

$database = new Database();
$conn = $database->getDb();

if (!$database->getState()) {
    echo json_encode(['success' => false, 'message' => $database->getErrMsg()]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    // Example: Handle login
    if (isset($data['email']) && isset($data['password'])) {
        $email = $data['email'];
        $password = $data['password'];

        // Example: Perform database query
        $user = $database->loginUser($email, $password);

        if ($user !== false) {
            // Example: Return user data
            echo json_encode(['success' => true, 'user' => $user]);
        } else {
            // Example: Return login failure message
            echo json_encode(['success' => false, 'message' => 'Invalid email or password']);
        }
    } else {
        // Invalid request, missing parameters
        echo json_encode(['success' => false, 'message' => 'Invalid request parameters']);
    }
} else {
    // Invalid request method
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
