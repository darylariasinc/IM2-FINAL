<?php

include '..object/object.php'; // Adjust the path accordingly

// Custom function for CORS headers
function cors() {
    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD, etc.
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }
}

// Call CORS function to set headers
cors();

header('Content-Type: application/json');

$database = new Database();
$conn = $database->getDb();

if (!$database->getState()) {
    die(json_encode(['success' => false, 'message' => $database->getErrMsg()]));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    // Check if the required fields are set
    if (
        isset($data['fname']) &&
        isset($data['lname']) &&
        isset($data['email']) &&
        isset($data['address']) &&
        isset($data['gender']) &&
        isset($data['birthdate']) &&
        isset($data['password'])
    ) {
        // Extract data from the request
        $fname = $data['fname'];
        $lname = $data['lname'];
        $email = $data['email'];
        $address = $data['address'];
        $gender = $data['gender'];
        $birthdate = $data['birthdate'];
        $password = password_hash($data['password'], PASSWORD_DEFAULT);

        // Perform your registration logic with PDO
        $stmt = $conn->prepare("INSERT INTO userinfo (fname, lname, email, address, gender, birthDate, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$fname, $lname, $email, $address, $gender, $birthdate, $password]);

        // Check if registration was successful
        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Registration successful']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Registration failed']);
        }
    } else {
        // Invalid request, missing parameters
        echo json_encode(['success' => false, 'message' => 'Invalid request']);
    }
} else {
    // Invalid request method
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
