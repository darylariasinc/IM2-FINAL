
<template>
  <div class="home">
    <h1>Login</h1>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="text" id="email" v-model="email" placeholder="Enter your email">
    </div>
    <div class="form-group">
      <label for="password">Password:</label>
      <input type="password" id="password" v-model="password" placeholder="Enter your password">
    </div>
    <button type="button" @click="login">Login</button>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
const router = useRouter();
const email = ref('');
const password = ref('');

const login = () => {
  const data = {
    email: email.value,
    password: password.value
  };

  fetch('http://localhost/im3d/api/handler/login.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: new URLSearchParams(data)
  })
  .then(response => {
    console.log('Response headers:', response.headers);
    return response.json();
  })
  .then(data => {
    console.log('Login response:', data);
    
    if (data.success) {
      router.push({ path: '/dashboard', query: { fname: data.fname } });
    } else {
      console.log('Login failed:', data.message);
    }
  })
  .catch(error => {
    console.error('Error:', error);
  });
};
const loadTodos = () => {
  // Access Todo component's methods using ref and call the loadTodos method
  const todoComponent = ref<Todo | null>(null);
  
  // Assuming loadTodos is a method in the Todo component
  if (todoComponent.value) {
    todoComponent.value.loadTodos();
  }
};
</script>




