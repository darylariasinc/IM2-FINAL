<template>
    <div>
      <!-- Display todos -->
      <ul>
        <li v-for="todo in todos" :key="todo.id">
          {{ todo.title }}
        </li>
      </ul>

      <div>
        <input type="text" v-model="newTodoInput" />
        <button @click="addTodo">Add Todo</button>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        todos: [], 
        newTodoInput: '' 
      };
    },
    methods: {
      addTodo() {
        if (this.newTodoInput.trim() !== '') {

          const todoId = Math.floor(Math.random() * 1000);
  
          const newTodo = {
            id: todoId,
            title: this.newTodoInput
          };
          this.todos.push(newTodo);
          this.newTodoInput = '';
        }
      }
    }
  };
  </script>