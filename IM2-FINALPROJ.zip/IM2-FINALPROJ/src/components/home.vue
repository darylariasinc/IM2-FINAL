<template>
  <div class="home">
    <h1>Register</h1>
    First Name: <input type="text" v-model="fname"><br>
    Last Name: <input type="text" v-model="lname"><br>
    Email: <input type="text" v-model="email"><br>
    Password: <input type="password" v-model="password"><br>
    <button type="button" @click="save">Register</button>
    <span v-for="name in names" :key="name">{{ name }}</span>
    <div v-if="showNotification">{{ notificationMessage }}</div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
const router = useRouter();

const fname = ref('');
const lname = ref('');
const email = ref('');
const password = ref('');
const names = ref([]);
const showNotification = ref(false);
const notificationMessage = ref('');
const fullName = ref('');

const save = () => {
  const formData = new FormData();
  formData.append('fname', fname.value);
  formData.append('lname', lname.value);
  formData.append('email', email.value);
  formData.append('password', password.value);

  fetch('http://localhost/im3d/api/handler/adminregister.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.json())
  .then(data => {
    console.log(data);
    fname.value = '';
    lname.value = '';
    email.value = '';
    password.value = '';

    showNotification.value = true;
    notificationMessage.value = 'Successfully created!';
    setTimeout(() => {
      showNotification.value = false;
      
      router.push({ path: '/login' }); // Redirect to the login page after successful registration
    }, 3000);
  })
  .catch(error => {
    console.error('Error:', error);
  });
};
</script>

