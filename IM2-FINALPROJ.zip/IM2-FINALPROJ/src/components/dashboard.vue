<template>
<div class="home">
   <h1>Welcome, {{ $route.query.fname }}</h1>
  </div>
</template>
<script>
</script>

<style >

</style>

