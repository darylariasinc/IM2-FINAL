<script setup>
import { defineComponent } from 'vue';
import Home from './components/home.vue';
import Login from './components/login.vue';

defineComponent({
  components: {
    Home,
    Login,
  }
});
</script>

<template>
  <div id="app">
    <header>
      <div class="wrapper">
   
      
      </div>
    </header>
    
    <router-view></router-view>
  </div>
</template>

<style scoped>
.wrapper{
  padding: 5px;
}
</style>